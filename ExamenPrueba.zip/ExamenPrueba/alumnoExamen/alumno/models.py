from django.db import models

class Alumno(models.Model):
    matricula = models.CharField(max_length=10)
    nombre = models.CharField(max_length=100)
    apellido = models.CharField(max_length=100)
    edad = models.IntegerField()
    correo = models.CharField(max_length=100)
    carrera = models.CharField(max_length=100)
    imagen = models.ImageField(upload_to='alumno/', blank=True, null=True)

    class meta :
        managed = True,
        db_table = 'alumno'

    def __str__(self):
        return self.matricula