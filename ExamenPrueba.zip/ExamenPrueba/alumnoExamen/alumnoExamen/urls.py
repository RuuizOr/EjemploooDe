from django.contrib import admin
from django.conf import settings
from django.conf.urls.static import static
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from alumno.views import AlumnoViewSet

routers = DefaultRouter()
routers.register(r'alumno',AlumnoViewSet)

urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/',include(routers.urls))
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)